import Image from "next/image"
import { CheckCircle } from "lucide-react"

interface Feature {
  title: string
  description: string
  image: string
  benefits: string[]
}

interface FeaturesShowcaseProps {
  features: Feature[]
}

export default function FeaturesShowcase({ features }: FeaturesShowcaseProps) {
  return (
    <div className="space-y-24">
      {features.map((feature, index) => (
        <div
          key={index}
          className={`flex flex-col ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"} gap-8 items-center`}
        >
          <div className="md:w-1/2">
            <div className="relative h-[400px] rounded-[25px] overflow-hidden shadow-md">
              <Image src={feature.image || "/placeholder.svg"} alt={feature.title} fill className="object-cover" />
            </div>
          </div>

          <div className="md:w-1/2">
            <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
            <p className="text-gray-700 mb-6">{feature.description}</p>

            <div className="space-y-3">
              {feature.benefits.map((benefit, idx) => (
                <div key={idx} className="flex items-start">
                  <CheckCircle className="h-5 w-5 text-brand-teal mr-3 mt-1 flex-shrink-0" />
                  <span className="text-gray-700">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}
