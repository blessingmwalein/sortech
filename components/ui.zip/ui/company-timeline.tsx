import { CheckCircle } from "lucide-react"

interface TimelineEvent {
  year: string
  title: string
  description: string
}

export default function CompanyTimeline() {
  const events: TimelineEvent[] = [
    {
      year: "2024",
      title: "Company Formation",
      description:
        "Sortech Private Limited was established in August 2024 to address the gap in both Zimbabwean consumer and commercial markets for effective technology solutions.",
    },
    {
      year: "2024",
      title: "First Major Client",
      description:
        "Secured our first enterprise client, implementing comprehensive security solutions for a leading financial institution in Zimbabwe.",
    },
    {
      year: "2024",
      title: "Home Automation Launch",
      description:
        "Launched our home automation division, bringing smart home technology to residential customers across Zimbabwe.",
    },
    {
      year: "2025",
      title: "Future Growth",
      description:
        "Expanding our service offerings and market reach to become the leading technology solutions provider in Zimbabwe and beyond.",
    },
  ]

  return (
    <div className="relative">
      {/* Timeline line */}
      <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-1 bg-brand-teal/30 transform md:-translate-x-1/2"></div>

      <div className="space-y-12">
        {events.map((event, index) => (
          <div
            key={index}
            className={`relative flex flex-col ${index % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"} items-center`}
          >
            <div className={`md:w-1/2 ${index % 2 === 0 ? "md:pr-12 md:text-right" : "md:pl-12"} mb-4 md:mb-0`}>
              <div className="bg-white p-6 rounded-[20px] shadow-md">
                <div className="text-brand-teal font-bold text-xl mb-2">{event.year}</div>
                <h3 className="text-xl font-semibold mb-2">{event.title}</h3>
                <p className="text-gray-600">{event.description}</p>
              </div>
            </div>

            <div className="z-10 w-10 h-10 rounded-full bg-brand-teal flex items-center justify-center">
              <CheckCircle className="h-5 w-5 text-white" />
            </div>

            <div className="md:w-1/2"></div>
          </div>
        ))}
      </div>
    </div>
  )
}
